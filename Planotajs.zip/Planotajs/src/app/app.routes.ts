import { Routes } from '@angular/router';
import { HomePage } from './pages/home-page';
import { BoardPage } from './pages/board-page';

export const routes: Routes = [
  { path: '', component: HomePage },
  { path: 'board/:id', component: BoardPage },
  { path: '**', redirectTo: '' },
];
