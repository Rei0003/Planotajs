import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { StorageService } from '../services/storage.service';
import { dueLabel, dueState, priorityLabel } from '../services/task-helpers';
import { Board, Task } from '../models';
import { Logo } from '../components/logo';
import { ThemeButton } from '../components/theme-button';

@Component({
  selector: 'app-home-page',
  imports: [FormsModule, RouterLink, Logo, ThemeButton],
  templateUrl: './home-page.html',
  changeDetection: ChangeDetectionStrategy.Eager,
})
export class HomePage {
  tab = 'active';
  sortBy = 'due';
  priorityFilter = 'all';

  dueLabel = dueLabel;
  dueState = dueState;
  priorityLabel = priorityLabel;

  constructor(public store: StorageService, private router: Router) {}

  activeTasks(): Task[] {
    return this.store.tasks.filter((task) => !task.done);
  }

  completedTasks(): Task[] {
    return this.store.tasks.filter((task) => task.done);
  }

  shownTasks(): Task[] {
    let list = this.tab === 'active' ? this.activeTasks() : this.completedTasks();
    if (this.priorityFilter !== 'all') {
      list = list.filter((task) => task.priority === this.priorityFilter);
    }

    const priorityOrder = { high: 1, medium: 2, low: 3 };
    return [...list].sort((a, b) => {
      if (this.sortBy === 'priority' && a.priority !== b.priority) {
        return priorityOrder[a.priority] - priorityOrder[b.priority];
      }
      return (a.due || '9999').localeCompare(b.due || '9999');
    });
  }

  listTitle(task: Task): string {
    return this.store.listOf(task)?.title || 'To-do list';
  }

  boardOf(task: Task): Board | undefined {
    const list = this.store.listOf(task);
    return list ? this.store.findBoard(list.boardId) : undefined;
  }

  toggleDone(task: Task) {
    task.done = !task.done;
    this.store.save();
  }

  newBoard() {
    const board = this.store.addBoard('Untitled board');
    this.router.navigate(['/board', board.id]);
  }

  deleteBoard(board: Board, event: Event) {
    event.preventDefault();
    event.stopPropagation();
    if (confirm(`Delete "${board.title}" and everything on it?`)) {
      this.store.deleteBoard(board.id);
    }
  }
}
