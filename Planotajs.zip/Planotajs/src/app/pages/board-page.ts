import { ChangeDetectionStrategy, Component, HostListener, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { StorageService } from '../services/storage.service';
import { Board, Card, Task } from '../models';
import { Logo } from '../components/logo';
import { ThemeButton } from '../components/theme-button';
import { NoteCard } from '../components/note-card';
import { TodoCard } from '../components/todo-card';
import { TaskDetails } from '../components/task-details';

@Component({
  selector: 'app-board-page',
  imports: [FormsModule, RouterLink, Logo, ThemeButton, NoteCard, TodoCard, TaskDetails],
  templateUrl: './board-page.html',
  changeDetection: ChangeDetectionStrategy.Eager,
})
export class BoardPage implements OnInit {
  board: Board | undefined;
  editingTask: Task | null = null;

  draggedCard: Card | null = null;
  dragStart = { mouseX: 0, mouseY: 0, cardX: 0, cardY: 0 };

  constructor(public store: StorageService, private route: ActivatedRoute, private router: Router) {}

  ngOnInit() {
    this.route.paramMap.subscribe((params) => {
      this.board = this.store.findBoard(Number(params.get('id')));
      if (!this.board) {
        this.router.navigate(['/']);
      }
    });
  }

  cards(): Card[] {
    return this.board ? this.store.cardsOf(this.board.id) : [];
  }

  addCard(type: 'note' | 'todo') {
    if (!this.board) return;
    const spot = this.findFreeSpot();
    this.store.addCard(this.board.id, type, spot.x, spot.y);
  }

  findFreeSpot() {
    for (let row = 0; row < 20; row++) {
      for (let column = 0; column < 5; column++) {
        const x = 60 + column * 320;
        const y = 50 + row * 260;
        const taken = this.cards().some((card) => Math.abs(card.x - x) < 300 && Math.abs(card.y - y) < 240);
        if (!taken) return { x, y };
      }
    }
    return { x: 60, y: 50 };
  }

  deleteCard(card: Card) {
    if (confirm('Delete this card?')) {
      this.store.deleteCard(card);
    }
  }

  startDrag(event: PointerEvent, card: Card) {
    event.preventDefault();
    this.draggedCard = card;
    this.dragStart = { mouseX: event.clientX, mouseY: event.clientY, cardX: card.x, cardY: card.y };
  }

  @HostListener('document:pointermove', ['$event'])
  drag(event: PointerEvent) {
    if (!this.draggedCard) return;
    this.draggedCard.x = Math.max(0, this.dragStart.cardX + event.clientX - this.dragStart.mouseX);
    this.draggedCard.y = Math.max(0, this.dragStart.cardY + event.clientY - this.dragStart.mouseY);
  }

  @HostListener('document:pointerup')
  stopDrag() {
    if (!this.draggedCard) return;
    this.draggedCard = null;
    this.store.save();
  }
}
