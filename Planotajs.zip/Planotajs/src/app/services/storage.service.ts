import { Injectable } from '@angular/core';
import { Board, Card, Task } from '../models';

@Injectable({ providedIn: 'root' })
export class StorageService {
  boards: Board[] = [];
  cards: Card[] = [];
  tasks: Task[] = [];
  nextId = 1;

  constructor() {
    const saved = localStorage.getItem('boards.flat');
    if (saved) {
      const data = JSON.parse(saved);
      this.boards = data.boards;
      this.cards = data.cards;
      this.tasks = data.tasks;
      this.nextId = data.nextId;
    }
  }

  save() {
    const data = { boards: this.boards, cards: this.cards, tasks: this.tasks, nextId: this.nextId };
    localStorage.setItem('boards.flat', JSON.stringify(data));
  }

  newId(): number {
    const id = this.nextId;
    this.nextId = this.nextId + 1;
    return id;
  }

  findBoard(id: number): Board | undefined {
    return this.boards.find((board) => board.id === id);
  }

  addBoard(title: string): Board {
    const board: Board = { id: this.newId(), title };
    this.boards.push(board);
    this.save();
    return board;
  }

  deleteBoard(id: number) {
    for (const card of this.cardsOf(id)) {
      this.tasks = this.tasks.filter((task) => task.cardId !== card.id);
    }
    this.cards = this.cards.filter((card) => card.boardId !== id);
    this.boards = this.boards.filter((board) => board.id !== id);
    this.save();
  }

  cardsOf(boardId: number): Card[] {
    return this.cards.filter((card) => card.boardId === boardId);
  }

  addCard(boardId: number, type: 'note' | 'todo', x: number, y: number) {
    this.cards.push({ id: this.newId(), boardId, type, x, y, title: '', text: '' });
    this.save();
  }

  deleteCard(card: Card) {
    this.tasks = this.tasks.filter((task) => task.cardId !== card.id);
    this.cards = this.cards.filter((other) => other.id !== card.id);
    this.save();
  }

  tasksOf(cardId: number): Task[] {
    return this.tasks.filter((task) => task.cardId === cardId);
  }

  addTask(cardId: number, title: string) {
    this.tasks.push({ id: this.newId(), cardId, title, description: '', due: '', priority: 'medium', done: false });
    this.save();
  }

  deleteTask(task: Task) {
    this.tasks = this.tasks.filter((other) => other.id !== task.id);
    this.save();
  }

  listOf(task: Task): Card | undefined {
    return this.cards.find((card) => card.id === task.cardId);
  }
}
