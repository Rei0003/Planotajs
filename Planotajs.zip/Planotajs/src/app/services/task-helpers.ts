function todayText(): string {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${now.getFullYear()}-${month}-${day}`;
}

export function dueState(due: string): string {
  if (!due) return '';
  const day = due.slice(0, 10);
  if (day < todayText()) return 'overdue';
  if (day === todayText()) return 'today';
  return 'later';
}

export function dueLabel(due: string): string {
  if (!due) return '';
  const [day, time] = due.split('T');
  const label = new Date(day + 'T00:00').toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
  return time ? `${label} ${time}` : label;
}

export function priorityLabel(priority: string): string {
  if (priority === 'high') return 'High';
  if (priority === 'low') return 'Low';
  return 'Medium';
}
