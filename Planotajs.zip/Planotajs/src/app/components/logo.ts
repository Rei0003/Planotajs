import { Component } from '@angular/core';

@Component({
  selector: 'app-logo',
  template: `
    <svg class="brand" viewBox="0 0 28 28" aria-hidden="true">
      <rect x="3" y="3" width="13" height="16" rx="2.5" fill="currentColor" />
      <rect x="12" y="9" width="13" height="16" rx="2.5" fill="none" stroke="currentColor" stroke-width="2" />
    </svg>
  `,
  styles: ':host { display: contents; }',
})
export class Logo {}
