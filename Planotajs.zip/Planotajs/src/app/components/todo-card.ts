import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StorageService } from '../services/storage.service';
import { dueLabel, dueState, priorityLabel } from '../services/task-helpers';
import { Card, Task } from '../models';

@Component({
  selector: 'app-todo-card',
  imports: [FormsModule],
  templateUrl: './todo-card.html',
  changeDetection: ChangeDetectionStrategy.Eager,
})
export class TodoCard {
  @Input() card!: Card;
  @Output() openTask = new EventEmitter<Task>();

  newTask = '';

  dueLabel = dueLabel;
  dueState = dueState;
  priorityLabel = priorityLabel;

  constructor(public store: StorageService) {}

  tasks(): Task[] {
    return this.store.tasksOf(this.card.id);
  }

  progress(): number {
    const tasks = this.tasks();
    if (tasks.length === 0) return 0;
    const done = tasks.filter((task) => task.done).length;
    return (done / tasks.length) * 100;
  }

  addTask() {
    const title = this.newTask.trim();
    if (title) {
      this.store.addTask(this.card.id, title);
      this.newTask = '';
    }
  }

  toggleDone(task: Task) {
    task.done = !task.done;
    this.store.save();
  }
}
