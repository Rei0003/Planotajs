import { ChangeDetectionStrategy, Component } from '@angular/core';

@Component({
  selector: 'app-theme-button',
  template: `
    <button class="theme-toggle" type="button" aria-label="Switch light / dark mode" (click)="switchTheme()">
      <svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round">
        <path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z" />
      </svg>
      <svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round">
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M5.3 18.7l1.4-1.4M17.3 6.7l1.4-1.4" />
      </svg>
    </button>
  `,
  styles: ':host { display: contents; }',
  changeDetection: ChangeDetectionStrategy.Eager,
})
export class ThemeButton {
  switchTheme() {
    const root = document.documentElement;
    let isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (root.dataset['theme']) {
      isDark = root.dataset['theme'] === 'dark';
    }

    const newTheme = isDark ? 'light' : 'dark';
    root.dataset['theme'] = newTheme;
    localStorage.setItem('boards.theme', newTheme);
  }
}
