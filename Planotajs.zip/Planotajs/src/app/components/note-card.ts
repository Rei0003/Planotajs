import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StorageService } from '../services/storage.service';
import { Card } from '../models';

@Component({
  selector: 'app-note-card',
  imports: [FormsModule],
  template: `
    <textarea class="note-text" placeholder="Write something…" maxlength="5000"
      [rows]="lineCount()" [(ngModel)]="card.text" (input)="store.save()"></textarea>
  `,
  changeDetection: ChangeDetectionStrategy.Eager,
})
export class NoteCard {
  @Input() card!: Card;

  constructor(public store: StorageService) {}

  lineCount(): number {
    return Math.max(3, this.card.text.split('\n').length + 1);
  }
}
