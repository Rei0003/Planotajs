import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StorageService } from '../services/storage.service';
import { Task } from '../models';

@Component({
  selector: 'app-task-details',
  imports: [FormsModule],
  templateUrl: './task-details.html',
  changeDetection: ChangeDetectionStrategy.Eager,
})
export class TaskDetails implements OnInit {
  @Input() task!: Task;
  @Output() closed = new EventEmitter<void>();

  title = '';
  description = '';
  date = '';
  time = '';
  priority: 'low' | 'medium' | 'high' = 'medium';

  titleError = '';
  dueError = '';

  constructor(private store: StorageService) {}

  ngOnInit() {
    this.title = this.task.title;
    this.description = this.task.description;
    this.priority = this.task.priority;
    this.date = this.task.due.slice(0, 10);
    this.time = this.task.due.slice(11, 16);
  }

  save() {
    this.titleError = this.title.trim() === '' ? 'Please give the task a title.' : '';
    this.dueError = this.time && !this.date ? 'Pick a date for this time (or clear the time).' : '';
    if (this.titleError || this.dueError) return;

    this.task.title = this.title.trim();
    this.task.description = this.description.trim();
    this.task.priority = this.priority;
    this.task.due = '';
    if (this.date) {
      this.task.due = this.time ? `${this.date}T${this.time}` : this.date;
    }
    this.store.save();
    this.closed.emit();
  }
}
