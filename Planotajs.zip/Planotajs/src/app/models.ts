export interface Board {
  id: number;
  title: string;
}

export interface Card {
  id: number;
  boardId: number;
  type: 'note' | 'todo';
  x: number;
  y: number;
  title: string;
  text: string;
}

export interface Task {
  id: number;
  cardId: number;
  title: string;
  description: string;
  due: string;
  priority: 'low' | 'medium' | 'high';
  done: boolean;
}
